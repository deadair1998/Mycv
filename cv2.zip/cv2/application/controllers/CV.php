<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CV extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin/Skill_model');
		$this->load->model('admin/Edu_model');
		$this->load->model('admin/Exp_model');
		$this->load->model('admin/Aboutme_model');
	}

	public function index()
	{
		$result = $this->Skill_model->get_all();
		$data['items1'] =  $result;
		$result2 = $this->Edu_model->get_all();
		$data['items2'] =  $result2;
		$result3 = $this->Exp_model->get_all();
		$data['items3'] =  $result3;
		$result4 = $this->Aboutme_model->getAllData();
		$data['items4'] =  $result4;
		$this->load->view('cv', $data);
	}

}

/* End of file CV.php */
/* Location: ./application/controllers/CV.php */
