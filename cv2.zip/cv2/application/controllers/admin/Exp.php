     <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Exp extends My_Controller {

	public function __construct()
	{
		parent::__construct();
    //load pagination libraries
    $this->load->library('pagination');
    // load model
    $this->load->model('admin/Exp_model');
    
	}
  public function index()
  {
    
    $result = $this->Exp_model->get_all();
    $data['items'] =  $result;
    //var_dump($result); die();
    $data['content'] = 'exp/index';
    $this->load->view('templates/master', $data);
  }

	public function loadRecord($cur_page =0)
	{  

    $cur_page = $this->input->get("per_page");  
    $search = $this->input->get("search");

    // config pagination
    $config['base_url'] = base_url("admin/Exp/index?search=$search");   
    $config['total_rows'] = $this->Exp_model->count_rows($search);   
    $config['per_page'] =  $this->Exp_model->count_rows($search);
    $config['page_query_string'] = TRUE;
    $config['full_tag_open'] = "<ul class = 'pagination'> ";
    $config['full_tag_close'] = '</ul>';
    // $config['base_url'] = 'url';
    // $config['total_rows'] = 100;
    // $config['per_page'] = 10;
    // $config['uri_segment'] = 3;
    // $config['num_links'] = 3; 
     
    // $config['first_link'] = 'First';
    // $config['first_tag_open'] = '<div>';
    // $config['first_tag_close'] = '</div>';
    // $config['last_link'] = 'Last';
    // $config['last_tag_open'] = '<div>';
    // $config['last_tag_close'] = '</div>';
    // $config['next_link'] = '&gt;';
    // $config['next_tag_open'] = '<div>';
    // $config['next_tag_close'] = '</div>';
    // $config['prev_link'] = '&lt;';
    // $config['prev_tag_open'] = '<div>';
    // $config['prev_tag_close'] = '</div>';
    // $config['cur_tag_open'] = '<b>';
    // $config['cur_tag_close'] = '</b>';
    
    $this->pagination->initialize($config);
   
    // echo $this->pagination->create_links();
    //
		
		//$data['items'] = $this->Users_model->get_all(); 

    $data['items'] = $this->Exp_model->get_search($search,$cur_page,$config['per_page']); 
    //var_dump($this->Users_model->get_search($search,$cur_page,$config['per_page'])); die();
		
		$data['content'] = 'exp/index';
		$this->load->view('templates/master', $data);
     //echo $this->pagination->create_links();
	}
	public function add ()
	{

		$this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    $data['content'] = 'exp/add';
		
    $this->form_validation->set_rules('heading', 'Heading', 'required');
    $this->form_validation->set_rules('name', ' Name', 'required');
		$this->form_validation->set_rules('detail', ' Detail', 'required');
		

        if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('templates/master',$data);
        }
        else
        {
               $heading = $this->input->post('heading');
               $name = $this->input->post('name');
               $detail = $this->input->post('detail');
           
               $arr = array(
               		'heading'=>$heading,
               		'name'=>$name,
               		'detail'=>$detail
               		
               	);              

              if ($this->Exp_model->add($arr)) 
              { 
                redirect('admin/Exp');
              } 
               
          }
	 }

   public function delete($id){
    $res = $this->Exp_model->delete($id);
    redirect('admin/Exp');   
   }

   public function update($id)
   {
      $data['content'] = 'exp/update';
      $value = $this->Exp_model->getDataById($id);
      $data['items'] = $value;
    
      $this->load->helper(array('form', 'url'));
      $this->load->library('form_validation');
      $this->form_validation->set_rules('heading', 'Heading', 'required');
      $this->form_validation->set_rules('name', ' Name', 'required');
      $this->form_validation->set_rules('detail', ' Detail', 'required');
     
      if ($this->form_validation->run() == FALSE) {
        $this->load->view('templates/master',$data);
      }else {
                $heading = $this->input->post('heading');
               $name = $this->input->post('name');
               $detail = $this->input->post('detail');
           
               $arr = array(
                  'heading'=>$heading,
                  'name'=>$name,
                  'detail'=>$detail
                  
                );      
      $res = $this->Exp_model->update($id,$arr); 
      redirect('admin/Exp');

    }

     

    
   }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */
