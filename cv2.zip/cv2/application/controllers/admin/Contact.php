     <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends My_Controller {

	public function __construct()
	{
		parent::__construct();
    //load pagination libraries
    $this->load->library('pagination');
    // load model
    $this->load->model('admin/Contact_model');
    
	}
  public function index()
  {
    
    $result = $this->Contact_model->get_all();
    $data['items'] =  $result;
    //var_dump($result); die();
    $data['content'] = 'contact/index';
    $this->load->view('templates/master', $data);
  }
  public function add ()
  {

    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    
    
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('content', 'content', 'required');
    

        if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('cv');
        }
        else
        {
               $name = $this->input->post('name');
               $email = $this->input->post('email');
               $subject = $this->input->post('subject');
               $content = $this->input->post('content');
              
               $arr = array(
                  'name'=>$name,
                  'email'=>$email,
                  'subject'=>$subject,
                  'content'=>$content
                  
                );                         
          }
           if ($this->Contact_model->add($arr)) {
                redirect('CV');
              }
             
   }

	public function loadRecord($cur_page =0)
	{  

    $cur_page = $this->input->get("per_page");  
    $search = $this->input->get("search");

    // config pagination
    $config['base_url'] = base_url("admin/Edu/index?search=$search");   
    $config['total_rows'] = $this->Edu_model->count_rows($search);   
    $config['per_page'] =  $this->Edu_model->count_rows($search);
    $config['page_query_string'] = TRUE;
    $config['full_tag_open'] = "<ul class = 'pagination'> ";
    $config['full_tag_close'] = '</ul>';
    // $config['base_url'] = 'url';
    // $config['total_rows'] = 100;
    // $config['per_page'] = 10;
    // $config['uri_segment'] = 3;
    // $config['num_links'] = 3; 
     
    // $config['first_link'] = 'First';
    // $config['first_tag_open'] = '<div>';
    // $config['first_tag_close'] = '</div>';
    // $config['last_link'] = 'Last';
    // $config['last_tag_open'] = '<div>';
    // $config['last_tag_close'] = '</div>';
    // $config['next_link'] = '&gt;';
    // $config['next_tag_open'] = '<div>';
    // $config['next_tag_close'] = '</div>';
    // $config['prev_link'] = '&lt;';
    // $config['prev_tag_open'] = '<div>';
    // $config['prev_tag_close'] = '</div>';
    // $config['cur_tag_open'] = '<b>';
    // $config['cur_tag_close'] = '</b>';
    
    $this->pagination->initialize($config);
   
    // echo $this->pagination->create_links();
    //
		
		//$data['items'] = $this->Users_model->get_all(); 

    $data['items'] = $this->Edu_model->get_search($search,$cur_page,$config['per_page']); 
    //var_dump($this->Users_model->get_search($search,$cur_page,$config['per_page'])); die();
		
		$data['content'] = 'edu/index';
		$this->load->view('templates/master', $data);
     //echo $this->pagination->create_links();
	}
	

   public function delete($id){
    $res = $this->Contact_model->delete($id);
    redirect('admin/Contact');   
   }



}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */
