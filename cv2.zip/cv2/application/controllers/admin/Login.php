<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		//$this->load->view('login.php');
		// kiểm tra đăng nhập
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username' ,"username","required");
		$this->form_validation->set_rules('username' ,"password","required");
		if ($this->form_validation->run() == FALSE) {
			// kiểm tra form đăng nhập trong trường hợp sai
			// redirect('admin/Login');
			$this->load->view('login.php');
		} else {
			// kiểm tra đăng nhập
			$this->load->model('admin/Users_model');
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$res = $this->Users_model->check_users($username,$password);
			if ($res == NULL) {
				// đăng nhập sai
				$this->session->set_flashdata("msg",'Tài khoản hoặc tên đăng nhập không hợp lệ');
				redirect('admin/Login');
			} else {
				// đăng nhập đúng
				$this->session->set_userdata("sucess",$res);
				redirect('admin/Users');
			}
		}
			
	}
	public function logout()
	{
		$this->session->unset_userdata('sucess');
		redirect('admin/Login');
	}

}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */