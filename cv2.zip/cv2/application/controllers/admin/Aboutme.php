<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Aboutme extends My_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->helper('path');
	}

	public function index()
	{
		$this->load->model('admin/Aboutme_model');
		$result = $this->Aboutme_model->getAllData();
		$arr['result'] = $result;

		$arr['content'] = 'aboutme/admin.php';
		$this->load->view('templates/master.php', $arr);
		// echo '<pre>';
		// var_dump($result);
		// echo '</pre>';
		
	}
	public function showDataById ($id)
	{
	
		$this->load->model('admin/Aboutme_model');
		$result = $this->Aboutme_model->showDataById($id);
		$arr['result'] = $result;
		$arr['content'] = 'aboutme/update.php';
		// đưa $ketqua sang view sửa
		$this->load->view('templates/master.php', $arr);
		
	}
	public  function updateData($id)
	{	
		 
		// upload ảnh
		$config['upload_path']          = './uploads/';
		
        $config['allowed_types']        = 'gif|jpg|png|jpeg|pdf';
        $config['max_size']             = 2048000;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;
        $this->load->library('upload', $config);

        $res = $this->upload->do_upload('avatar');

       	$data = array('upload_data' => $this->upload->data());
      	
		       	 
        echo '<pre>';
        var_dump($res);
        echo '</pre>';die();

		
		$name = $this->input->post('name');
		$detail = $this->input->post('detail');
		$phone = $this->input->post('phone');
		$address = $this->input->post('address');
		$email = $this->input->post('email');
		$facebook = $this->input->post('facebook'); 
		$this->load->model('admin/Aboutme_model');
		if ($this->Aboutme_model->updateData($id,$name,$detail,$phone,$address,$email)) {
			echo 'thành công ';
		} else {
			echo 'fail';
		}
		
		
	}

}

/* End of file Aboutme.php */
/* Location: ./application/controllers/Aboutme.php */