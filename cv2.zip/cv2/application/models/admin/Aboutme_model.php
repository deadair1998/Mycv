<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Aboutme_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}
	public function getAllData()
	{
		$result = $this->db->get('aboutme');
		$res = $result->row_array();
		return $res;

	}
	public  function showDataById($id)
	{
		
		$this->db->where('id_aboutme', $id);
		$dulieu = $this->db->get('aboutme');
		$dulieu = $dulieu->result_array();
		
		return $dulieu;
	}
	public  function UpdateData($id,$name,$detail,$phone,$address,$email)
	{
		
		$data = array(		
		'name' => $name,
		'detail' => $detail,
		'phone' => $phone,
		'address' => $address,
		'email' => $email		
		);	
		$this->db->where('id_aboutme', $id);
		$result = $this->db->update('aboutme', $data);							
		return $result;
	}

}

/* End of file Aboutme_model.php */
/* Location: ./application/models/Aboutme_model.php */