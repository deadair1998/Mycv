<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact_model extends CI_Model {

	var $table = "contact";
	var $primaryKey = "id_edu";

	public function __construct()
	{
		parent::__construct();
		
	}
	// lấy tất cả dữ liệu từ database
	public function get_all()
	{
		return $this->db->get($this->table)->result_array();
	}
	// thêm dữ liệu vào database
	public  function add($arr)
	{
		return $this->db->insert($this->table,$arr);
	}
	// xóa dữ liệu theo id
	public function delete($id)
	{
		$this->db->where('id_contact', $id);
		return $this->db->delete($this->table);
	}
	// lấy dữ liệu theo id
	public function getDataById($id)
	{
		$this->db->where('id_edu', $id);
		return $this->db->get($this->table)->row_array();
	}
	//update dữ liệu theo id 
	public function update($id,$arr)
	{
		$this->db->where('id_edu', $id);
		return $this->db->update($this->table,$arr);

	}
	// đếm số dòng sau khi search (SELECT * FROM 'users' WHERE username LIKE %$search%)
	public function count_rows($search){
		$this->db->like('username',"$search" );
		return $this->db->count_all_results($this->table);
	}
	// lấy tất cả dữ liệu sau khi search (SELECT * FROM 'users' WHERE username LIKE %$search%)
	public  function get_search($search,$cur_page,$per_page)
	{
		$this->db->like('username',"$search" );
		return $query = $this->db->get($this->table, $per_page, $cur_page)->result_array();
	}
	// lấy dữ diệu sau khi kiểm tra đăng nhập
	public function check_users($username,$password)
	{
		$this->db->where("username ='$username' AND password='$password' ");
		$result = $this->db->get($this->table)->row_array();
		return $result;
	}
	

}

/* End of file Users_model.php */
/* Location: ./application/models/Users_model.php */