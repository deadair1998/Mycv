
<div class="container">
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Skill/add" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Name skill</label>
	    <input type="text" class="form-control" placeholder="name" name="name">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Score</label>
	    <input type="text" class="form-control" placeholder="score" name="score">
	  </div>

		  	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Users" class="btn btn-secondary">Back</a>

	</form>
</div>
