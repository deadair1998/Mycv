
<div class="container">
	
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Skill/update/<?= $items['id_skill'] ?>" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Name Skill</label>
	    <input type="text" class="form-control"  name="name" value="<?= $items['name'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Password</label>
	    <input type="text" class="form-control"  name="score" value="<?= $items['score'] ?>">
	  </div>

	  	  	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Skill" class="btn btn-secondary">Back</a>

	</form>
</div>
