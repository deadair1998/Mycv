
<div class="container">
	
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Edu/update/<?= $items['id_edu'] ?>" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Name Level</label>
	    <input type="text" class="form-control"  name="name_level" value="<?= $items['name_level'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">School Name</label>
	    <input type="text" class="form-control"  name="name_school" value="<?= $items['name_school'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Start year</label>
	    <input type="text" class="form-control"  name="start" value="<?= $items['start'] ?>">
	  </div>
	  <div class="form-group">
	    <label for="exampleInputEmail1">End year</label>
	    <input type="text" class="form-control"  name="end" value="<?= $items['end'] ?>">
	  </div>
		
	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Edu" class="btn btn-secondary">Back</a>

	</form>
</div>
