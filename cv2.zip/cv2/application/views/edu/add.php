<br>
<div class="container">
	<br>
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Edu/add" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Name level</label>
	    <input type="text" class="form-control" placeholder="name level" name="name_level">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">School Name</label>
	    <input type="text" class="form-control" placeholder="name school" name="name_school">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Start year</label>
	    <input type="number" class="form-control" placeholder="start year" name="start">
	  </div>
	  <div class="form-group">
	    <label for="exampleInputEmail1">End year</label>
	    <input type="number" class="form-control" placeholder="end year" name="end">
	  </div>

	  	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Edu" class="btn btn-secondary">Back</a>

	</form>
</div>
