
<div class="container">
  <br>
    <div class="row">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="pull-right">
          <a href="<?= base_url() ?>index.php/admin/Edu/add " class="btn btn-success  fa fa-plus" > Add more</a>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <form action="<?= base_url() ?>index.php/admin/Edu/loadRecord" method="get">
          <input type="text" name="search" value="<?php $this->input->get("search") ?>" >
          <input type="submit" class="btn btn-primary " value="Search">
         
        </form>
      </div>
    </div>
 
  
  
  <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Level</th>
      <th scope="col">Scholl name</th>
      <th scope="col">Start year</th>
      <th scope="col">End year</th>
      <th scope="col">features</th>
    </tr>
  </thead>
  <?php foreach ($items as $value): ?>     
    <tbody>
      <tr>
        <th scope="row"><?= $value['id_edu'] ?></th>
        <td><?= $value['name_level'] ?></td>
        <td><?= $value['name_school'] ?></td>
        <td><?= $value['start'] ?></td>
        <td><?= $value['end'] ?></td>
        <td>
         
          <a href="<?= base_url() ?>index.php/admin/Edu/update/<?= $value['id_edu'] ?>" class="btn btn-secondary fa fa-pen"></a>
          <a href="<?= base_url() ?>index.php/admin/Edu/delete/<?= $value['id_edu'] ?>"  
            onclick="return confirm('Bạn có chắc là muốn xóa không ?');" class="btn btn-secondary fa fa-trash" id="delete">           
          </a>
          
          
        </td>
      </tr>
    </tbody>
  <?php endforeach ?>

</table>


</div>
