
<div class="container">
	
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Users/update/<?= $items['id'] ?>" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Username</label>
	    <input type="text" class="form-control"  name="username" value="<?= $items['username'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Password</label>
	    <input type="text" class="form-control"  name="password" value="<?= $items['password'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Fullname</label>
	    <input type="text" class="form-control"  name="fullname" value="<?= $items['fullname'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleFormControlSelect1">Role</label>
	    <select class="form-control" id="exampleFormControlSelect1" name="role" value="<?= $items['role'] ?>">
	      <option value="mod">Mod</option>
	      <option value="admin">Admin</option>	      
	    </select>
	  </div>
	  <div class="form-group">

	    <label for="exampleFormControlSelect1">Status</label>
	    <select class="form-control" id="exampleFormControlSelect1" name="status" value="<?= $items['status'] ?>">
	      <option >0</option>
	      <option >1</option>	      
	    </select>
	  </div>	  	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Users" class="btn btn-secondary">Back</a>

	</form>
</div>
