<div class="container">
	
	 <?php foreach ($result as $value): ?>	 
	 <?php echo form_open_multipart( "admin/Aboutme/updateData/$value[id_aboutme]");?>
	  	
	  <div class="form-group">
	    <label for="exampleInputEmail1">Name</label>
	    <input type="text" class="form-control"  value="<?= $value['name'] ?>" name="name"	>	    
	  </div>

	  <div class="form-group">
	    <label for="exampleInputPassword1">Detail</label>
	    <input type="text" class="form-control" id="exampleInputPassword1" value="<?= $value['detail'] ?>" name="detail">
	  </div>
	  
	  <div class="form-group">
	    <label for="exampleInputPassword1">Phone</label>
	    <input type="text" class="form-control" id="exampleInputPassword1" value="<?= $value['phone'] ?>" name="phone">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputPassword1">Address</label>
	    <input type="text" class="form-control" id="exampleInputPassword1" value="<?= $value['address'] ?>" name="address">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputPassword1">Email</label>
	    <input type="text" class="form-control" id="exampleInputPassword1" value="<?= $value['email'] ?>" name="email">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputPassword1">Facebook</label>
	    <input type="text" class="form-control" id="exampleInputPassword1" value="<?= $value['facebook'] ?>" name="facebook">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputPassword1">Avatar</label>
	    <input type="file" class="form-control" id="exampleInputPassword1"  name="avatar">
	  </div>
	  
	  
	  <input type="submit" class="btn btn-primary" value="Submit"></input>
	  <a href="<?= base_url() ?>index.php/admin/Aboutme" class="btn btn-secondary">Back</a>
	 
	</form>
	 <?php endforeach ?>
</div>