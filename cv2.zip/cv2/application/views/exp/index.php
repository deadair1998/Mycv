
<div class="container">
  <br>
    <div class="row">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="pull-right">
          <a href="<?= base_url() ?>index.php/admin/Exp/add " class="btn btn-success  fa fa-plus" > Add more</a>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <form action="<?= base_url() ?>index.php/admin/Exp/loadRecord" method="get">
          <input type="text" name="search" value="<?php $this->input->get("search") ?>" >
          <input type="submit" class="btn btn-primary " value="Search">
         
        </form>
      </div>
    </div>
 
  
  
  <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Heading</th>
      <th scope="col"> Name</th>
      <th scope="col">Detail</th>
 
    </tr>
  </thead>
  <?php foreach ($items as $value): ?>     
    <tbody>
      <tr>
        <th scope="row"><?= $value['id_exp'] ?></th>
        <td><?= $value['heading'] ?></td>
        <td><?= $value['name'] ?></td>
        <td><?= $value['detail'] ?></td>
       
        <td>
         
          <a href="<?= base_url() ?>index.php/admin/Exp/update/<?= $value['id_exp'] ?>" class="btn btn-secondary fa fa-pen"></a>
          <a href="<?= base_url() ?>index.php/admin/Exp/delete/<?= $value['id_exp'] ?>"  
            onclick="return confirm('Bạn có chắc là muốn xóa không ?');" class="btn btn-secondary fa fa-trash" id="delete">           
          </a>
          
          
        </td>
      </tr>
    </tbody>
  <?php endforeach ?>

</table>


</div>
