
<div class="container">
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Exp/add" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Heading</label>
	    <input type="text" class="form-control" placeholder="heading" name="heading">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Name</label>
	    <input type="text" class="form-control" placeholder="name" name="name">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Detail</label>
	    <input type="text" class="form-control" placeholder="detail" name="detail">
	  </div>

	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Exp" class="btn btn-secondary">Back</a>

	</form>
</div>
