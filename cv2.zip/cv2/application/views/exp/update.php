
<div class="container">
	<?php echo validation_errors(); ?>
	<form action="<?= base_url() ?>index.php/admin/Exp/update/<?= $items['id_exp'] ?>" method="post">
	  <div class="form-group">
	    <label for="exampleInputEmail1">Heading</label>
	    <input type="text" class="form-control" placeholder="heading" name="heading" value="<?= $items['heading'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Name</label>
	    <input type="text" class="form-control" placeholder="name" name="name" value="<?= $items['name'] ?>">
	  </div>

	  <div class="form-group">
	    <label for="exampleInputEmail1">Detail</label>
	    <input type="text" class="form-control" placeholder="detail" name="detail" value="<?= $items['detail'] ?>" >
	  </div>

	  
	  <button type="submit" class="btn btn-primary">Submit</button>
	  <a href="<?= base_url() ?>index.php/admin/Exp" class="btn btn-secondary">Back</a>

	</form>
</div>
