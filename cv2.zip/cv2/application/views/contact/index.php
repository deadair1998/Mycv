
<div class="container">
  <br>
    <div class="row">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="pull-right">
          
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <form action="<?= base_url() ?>index.php/admin/Contact/loadRecord" method="get">
          <input type="text" name="search" value="<?php $this->input->get("search") ?>" >
          <input type="submit" class="btn btn-primary " value="Search">
         
        </form>
      </div>
    </div>
 
  
  
  <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Subject</th>
      <th scope="col">Content</th>
      <th scope="col">features</th>
    </tr>
  </thead>
  <?php foreach ($items as $value): ?>     
    <tbody>
      <tr>
        <th scope="row"><?= $value['id_contact'] ?></th>
        <td><?= $value['name'] ?></td>
        <td><?= $value['email'] ?></td>
        <td><?= $value['subject'] ?></td>
        <td><?= $value['content'] ?></td>
        <td>
         
          
          <a href="<?= base_url() ?>index.php/admin/Contact/delete/<?= $value['id_contact'] ?>"  
            onclick="return confirm('Bạn có chắc là muốn xóa không ?');" class="btn btn-secondary fa fa-trash" id="delete">           
          </a>
          
          
        </td>
      </tr>
    </tbody>
  <?php endforeach ?>

</table>


</div>
