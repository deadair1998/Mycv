<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class My_controller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if ($this->session->has_userdata('sucess') == false) {
      	redirect('admin/Login');
    }
    
	}

	
}

/* End of file My_controller.php */
/* Location: ./application/controllers/My_controller.php */